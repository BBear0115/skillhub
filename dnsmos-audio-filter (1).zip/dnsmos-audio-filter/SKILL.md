---
name: dnsmos-audio-filter
description: Score single or batch audio files with DNSMOS and optionally split them into high/low quality folders using a local ONNX model. Use when users ask to run DNSMOS quality scoring, filter large audio folders by MOS threshold, export DNSMOS CSV reports, or process wav/mp3/flac/m4a/ogg audio with sig_bak_ovr.onnx.
---

# DNSMOS Audio Filter

Use this skill to run deterministic DNSMOS scoring on local audio files.

## Collect Inputs

Gather these values first:

- `input_dir`: folder containing audio files
- `model_path`: ONNX model path
  - default bundled model: `assets/sig_bak_ovr.onnx`
- `threshold`: split rule for overall MOS (`OVRL`)
  - default: `1.3`
- `workers`: thread count for batch processing
- `output_dir`: optional output folder
  - default: sibling folder `<input_dir>_dnsmos`

## Run Batch Scoring

Run the script:

```powershell
python scripts/dnsmos_batch_filter.py `
  --input-dir "D:\data\audio" `
  --model-path "assets\sig_bak_ovr.onnx" `
  --threshold 1.3 `
  --workers 4 `
  --copy-textgrid
```

Use an explicit Python interpreter when needed:

```powershell
D:\project\06-AudioUnderstand\.venv\Scripts\python.exe `
  D:\project\codex_code\skills\dnsmos-audio-filter\scripts\dnsmos_batch_filter.py `
  --input-dir "D:\data\audio" `
  --model-path "D:\project\codex_code\skills\dnsmos-audio-filter\assets\sig_bak_ovr.onnx"
```

## Check Outputs

Expect these artifacts under `output_dir`:

- `dnsmos_scores.csv`: per-file DNSMOS metrics (`OVRL`, `SIG`, `BAK`)
- `high_quality/`: files with `OVRL >= threshold`
- `low_quality/`: files with `OVRL < threshold`
- optional copied `.TextGrid` files when `--copy-textgrid` is set

## Apply Safety Rules

- Keep `--model-path` consistent with the intended DNSMOS model.
- Set `--strict` for automation; command returns non-zero when any file fails.
- Reduce `--workers` if disk or decode throughput becomes unstable.
- Install missing dependencies in the target environment:
  - `pip install numpy librosa onnxruntime soundfile`

## Script

- `scripts/dnsmos_batch_filter.py`: batch scoring, CSV export, threshold split, optional TextGrid copy.
