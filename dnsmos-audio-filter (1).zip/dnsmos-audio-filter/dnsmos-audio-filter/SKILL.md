---
name: dnsmos-audio-filter
description: Score single or batch audio files with DNSMOS and output a per-file score table (console + CSV) using a local ONNX model. Use when users ask for DNSMOS scoring reports only, batch quality scoring without moving/copying files, or OVRL/SIG/BAK tables for wav/mp3/flac/m4a/ogg audio with sig_bak_ovr.onnx.
---

# DNSMOS Audio Filter

Use this skill to run DNSMOS scoring and output score tables only.

## Collect Inputs

Gather these values first:

- `input_dir`: folder containing audio files
- `model_path`: ONNX model path
  - default bundled model: `assets/sig_bak_ovr.onnx`
- `output_csv`: output CSV path
  - default: `<input_dir>_dnsmos_scores.csv` next to input folder
- `workers`: thread count for batch processing

## Run Scoring

```powershell
python scripts/dnsmos_batch_filter.py `
  --input-dir "D:\data\audio" `
  --model-path "assets\sig_bak_ovr.onnx" `
  --output-csv "D:\data\audio_dnsmos_scores.csv" `
  --workers 4
```

Use an explicit Python interpreter when needed:

```powershell
D:\project\06-AudioUnderstand\.venv\Scripts\python.exe `
  D:\project\codex_code\skills\dnsmos-audio-filter\scripts\dnsmos_batch_filter.py `
  --input-dir "D:\data\audio" `
  --model-path "D:\project\codex_code\skills\dnsmos-audio-filter\assets\sig_bak_ovr.onnx"
```

## Check Outputs

Expect only table outputs:

- Console markdown table: `relative_path`, `OVRL`, `SIG`, `BAK`, `status`
- CSV table file: `relative_path`, `filename`, `OVRL`, `SIG`, `BAK`, `status`, `error`

The script does not move, copy, or classify source audio files.

## Apply Safety Rules

- Keep `--model-path` consistent with the intended DNSMOS model.
- Set `--strict` for automation; command returns non-zero when any file fails.
- Reduce `--workers` if decode throughput is unstable.
- Install missing dependencies in the target environment:
  - `pip install numpy librosa onnxruntime soundfile`

## Script

- `scripts/dnsmos_batch_filter.py`: batch scoring and score table export only.
