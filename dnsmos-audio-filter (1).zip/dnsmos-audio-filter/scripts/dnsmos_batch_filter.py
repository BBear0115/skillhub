#!/usr/bin/env python
"""Batch DNSMOS scoring and threshold-based audio splitting."""

from __future__ import annotations

import argparse
import csv
import math
import os
import shutil
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, Iterable, List

import librosa
import numpy as np
import onnxruntime as ort

SAMPLING_RATE = 16000
INPUT_LENGTH = 9.01
DEFAULT_EXTENSIONS = ".wav,.mp3,.flac,.m4a,.ogg"
THREAD_LOCAL = threading.local()


class DNSMOSScorer:
    """Compute DNSMOS metrics using an ONNX model."""

    def __init__(self, model_path: Path, device: str = "cpu") -> None:
        providers = ["CPUExecutionProvider"]
        if device == "cuda":
            providers = ["CUDAExecutionProvider", "CPUExecutionProvider"]
        self.session = ort.InferenceSession(str(model_path), providers=providers)

    @staticmethod
    def _polyfit(sig: float, bak: float, ovr: float, personalized: bool) -> tuple[float, float, float]:
        if personalized:
            p_ovr = np.poly1d([-0.00533021, 0.005101, 1.18058466, -0.11236046])
            p_sig = np.poly1d([-0.01019296, 0.02751166, 1.19576786, -0.24348726])
            p_bak = np.poly1d([-0.04976499, 0.44276479, -0.1644611, 0.96883132])
        else:
            p_ovr = np.poly1d([-0.06766283, 1.11546468, 0.04602535])
            p_sig = np.poly1d([-0.08397278, 1.22083953, 0.0052439])
            p_bak = np.poly1d([-0.13166888, 1.60915514, -0.39604546])
        return float(p_sig(sig)), float(p_bak(bak)), float(p_ovr(ovr))

    def score_path(self, audio_path: Path, personalized: bool) -> Dict[str, float]:
        audio, _ = librosa.load(str(audio_path), sr=SAMPLING_RATE, mono=True)
        if audio.size == 0:
            raise ValueError("Empty audio")

        len_samples = int(INPUT_LENGTH * SAMPLING_RATE)
        while len(audio) < len_samples:
            audio = np.append(audio, audio)

        hop_len = SAMPLING_RATE
        num_hops = int(math.floor((len(audio) - len_samples) / hop_len)) + 1

        sig_raw_values: List[float] = []
        bak_raw_values: List[float] = []
        ovr_raw_values: List[float] = []
        sig_values: List[float] = []
        bak_values: List[float] = []
        ovr_values: List[float] = []

        for hop in range(num_hops):
            start = hop * hop_len
            end = start + len_samples
            segment = audio[start:end]
            if len(segment) < len_samples:
                continue

            features = np.asarray(segment, dtype=np.float32)[np.newaxis, :]
            outputs = self.session.run(None, {"input_1": features})
            sig_raw, bak_raw, ovr_raw = outputs[0][0]
            sig, bak, ovr = self._polyfit(float(sig_raw), float(bak_raw), float(ovr_raw), personalized)

            sig_raw_values.append(float(sig_raw))
            bak_raw_values.append(float(bak_raw))
            ovr_raw_values.append(float(ovr_raw))
            sig_values.append(sig)
            bak_values.append(bak)
            ovr_values.append(ovr)

        if not ovr_values:
            raise ValueError("No valid DNSMOS windows")

        return {
            "OVRL_raw": float(np.mean(ovr_raw_values)),
            "SIG_raw": float(np.mean(sig_raw_values)),
            "BAK_raw": float(np.mean(bak_raw_values)),
            "OVRL": float(np.mean(ovr_values)),
            "SIG": float(np.mean(sig_values)),
            "BAK": float(np.mean(bak_values)),
        }


def get_thread_scorer(model_path: Path, device: str) -> DNSMOSScorer:
    scorer = getattr(THREAD_LOCAL, "scorer", None)
    scorer_key = getattr(THREAD_LOCAL, "scorer_key", None)
    current_key = (str(model_path.resolve()), device)
    if scorer is None or scorer_key != current_key:
        scorer = DNSMOSScorer(model_path=model_path, device=device)
        THREAD_LOCAL.scorer = scorer
        THREAD_LOCAL.scorer_key = current_key
    return scorer


def iter_audio_files(input_dir: Path, extensions_csv: str) -> Iterable[Path]:
    extensions = {
        ext.lower() if ext.startswith(".") else f".{ext.lower()}"
        for ext in (part.strip() for part in extensions_csv.split(","))
        if ext
    }
    for path in input_dir.rglob("*"):
        if path.is_file() and path.suffix.lower() in extensions:
            yield path


def process_one(
    audio_path: Path,
    input_dir: Path,
    output_dir: Path,
    model_path: Path,
    threshold: float,
    device: str,
    personalized: bool,
    copy_textgrid: bool,
) -> Dict[str, str]:
    scorer = get_thread_scorer(model_path=model_path, device=device)
    scores = scorer.score_path(audio_path=audio_path, personalized=personalized)

    label = "high_quality" if scores["OVRL"] >= threshold else "low_quality"
    relative_path = audio_path.relative_to(input_dir)
    target_audio = output_dir / label / relative_path
    target_audio.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(audio_path, target_audio)

    if copy_textgrid:
        textgrid_path = audio_path.with_suffix(".TextGrid")
        if textgrid_path.exists():
            target_textgrid = target_audio.with_suffix(".TextGrid")
            target_textgrid.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(textgrid_path, target_textgrid)

    return {
        "relative_path": str(relative_path).replace("\\", "/"),
        "filename": audio_path.name,
        "OVRL": f"{scores['OVRL']:.6f}",
        "SIG": f"{scores['SIG']:.6f}",
        "BAK": f"{scores['BAK']:.6f}",
        "label": label,
        "error": "",
    }


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Batch DNSMOS scoring with threshold-based folder split")
    parser.add_argument("--input-dir", required=True, help="Input directory containing audio files")
    parser.add_argument("--model-path", help="Path to DNSMOS ONNX model")
    parser.add_argument("--output-dir", help="Output directory (default: <input_dir>_dnsmos)")
    parser.add_argument("--threshold", type=float, default=1.3, help="OVRL threshold for high_quality")
    parser.add_argument("--workers", type=int, default=max(1, os.cpu_count() // 2), help="Thread count")
    parser.add_argument("--extensions", default=DEFAULT_EXTENSIONS, help="Comma-separated extensions")
    parser.add_argument("--copy-textgrid", action="store_true", help="Copy paired .TextGrid files if present")
    parser.add_argument("--personalized", action="store_true", help="Use personalized MOS polynomial")
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu", help="ONNX runtime device")
    parser.add_argument("--strict", action="store_true", help="Return non-zero if any file fails")
    return parser.parse_args()


def main() -> int:
    args = parse_args()

    input_dir = Path(args.input_dir).expanduser().resolve()
    if not input_dir.is_dir():
        print(f"ERROR input-dir does not exist or is not a directory: {input_dir}")
        return 2

    if args.model_path:
        model_path = Path(args.model_path).expanduser().resolve()
    else:
        model_path = (Path(__file__).resolve().parent.parent / "assets" / "sig_bak_ovr.onnx").resolve()

    if not model_path.is_file():
        print(f"ERROR model file not found: {model_path}")
        return 2

    if args.output_dir:
        output_dir = Path(args.output_dir).expanduser().resolve()
    else:
        output_dir = input_dir.parent / f"{input_dir.name}_dnsmos"
    output_dir.mkdir(parents=True, exist_ok=True)

    audio_files = sorted(iter_audio_files(input_dir=input_dir, extensions_csv=args.extensions))
    if not audio_files:
        print("ERROR no audio files matched the given extensions")
        return 2

    print(f"INPUT_DIR={input_dir}")
    print(f"MODEL_PATH={model_path}")
    print(f"OUTPUT_DIR={output_dir}")
    print(f"FILES={len(audio_files)}")
    print(f"WORKERS={args.workers}")

    results: List[Dict[str, str]] = []
    failures: List[Dict[str, str]] = []

    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor:
        future_map = {
            executor.submit(
                process_one,
                audio_path,
                input_dir,
                output_dir,
                model_path,
                args.threshold,
                args.device,
                args.personalized,
                args.copy_textgrid,
            ): audio_path
            for audio_path in audio_files
        }

        for future in as_completed(future_map):
            audio_path = future_map[future]
            try:
                row = future.result()
                results.append(row)
                print(f"OK {row['label']} {row['relative_path']} OVRL={row['OVRL']}")
            except Exception as exc:  # pylint: disable=broad-except
                relative_path = str(audio_path.relative_to(input_dir)).replace("\\", "/")
                error_row = {
                    "relative_path": relative_path,
                    "filename": audio_path.name,
                    "OVRL": "",
                    "SIG": "",
                    "BAK": "",
                    "label": "failed",
                    "error": str(exc),
                }
                failures.append(error_row)
                print(f"FAIL {relative_path} error={exc}")

    rows = sorted(results + failures, key=lambda item: item["relative_path"])

    csv_path = output_dir / "dnsmos_scores.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=["relative_path", "filename", "OVRL", "SIG", "BAK", "label", "error"],
        )
        writer.writeheader()
        writer.writerows(rows)

    print(f"CSV={csv_path}")
    print(f"SUMMARY ok={len(results)} fail={len(failures)} total={len(audio_files)}")

    if args.strict and failures:
        return 3
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
